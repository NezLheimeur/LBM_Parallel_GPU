#include <stdio.h>
#include <stdlib.h>
#include "lbmParams.h"
#include "real_type.h"
#include "lbmUtilities.h"
#include "stdint.h"

#ifndef M_PI
#define M_PI 3.1415
#endif

double compute_vel(int dir,
                   int i,
                   int j,
                   double uLB,
                   double ly)
{

  // flow is along X axis
  // X component is non-zero
  // Y component is always zero

  return (1 - dir) * uLB * (1 + 1e-4 * sin(j / ly * 2 * M_PI));

} // compute_vel

void init_obstacle_mask(const LBMParams &params,
                        uint8_t *obstacle)
{

  const int nx = params.nx;
  const int ny = params.ny;

  const double cx = params.cx;
  const double cy = params.cy;

  const double r = params.r;

#pragma acc parallel loop gang vector vector_length(32) present(obstacle)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {

      int index = i + nx * j;

      double x = 1.0 * i;
      double y = 1.0 * j;

      obstacle[index] = (x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r ? 1 : 0;

    } // end for i
  }   // end for j
} // init_obstacle_mask

void initialize_macroscopic_variables(const LBMParams &params,
                                      double *rho,
                                      double *ux,
                                      double *uy)
{

  const int nx = params.nx;
  const int ny = params.ny;
  const double uLB = params.uLB;
  const double ly = params.ly;

#pragma acc parallel loop gang vector vector_length(128) present(rho, ux, uy)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {
      ux[i + nx * j] = compute_vel(0, i, j, uLB, ly);
      rho[i + nx * j] = 1.0;
    } // end for i
  }   // end for j

#pragma acc parallel loop gang vector vector_length(64) num_gangs(128) present(rho, ux, uy)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {
      uy[i + nx * j] = compute_vel(1, i, j, uLB, ly);
    } // end for i
  }   // end for j  //End of init Macro Vars OpenACC region

} // initialize_macroscopic_variables

void initialize_equilibrium(const LBMParams &params,
                            const double *v,
                            const double *t,
                            const double *rho,
                            const double *ux,
                            const double *uy,
                            double *fin)
{

  const int nx = params.nx;
  const int ny = params.ny;
  const int npop = params.npop;

#pragma acc parallel loop gang vector vector_length(32) present(ux, uy, fin, rho, t, v)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {
      double cu = 0.0;
      int index = i + nx * j;

      double uX = ux[index];
      double uY = uy[index];

      double usqr = 3.0 / 2 * (uX * uX + uY * uY);
#pragma acc loop seq
      for (int ipop = 0; ipop < npop; ++ipop)
      {
        cu = 3 * (v[ipop * 2] * uX +
                  v[ipop * 2 + 1] * uY);

        fin[index + ipop * nx * ny] = rho[index] * t[ipop] * (1 + cu + 0.5 * cu * cu - usqr);
      }

    } // end for i
  }   // end for j
} // equilibrium

////////////////////////////////////////////LOOOOOOOOOOOOOOOPPP/////////////////////////////////////////////

// ======================================================
void border_outflow(const LBMParams &params,
                    double *fin)
{

  const int nx = params.nx;
  const int ny = params.ny;

  const int nxny = nx * ny;

  const int i1 = nx - 1;
  const int i2 = nx - 2;
#pragma acc parallel loop present(fin)
  for (int j = 0; j < ny; ++j)
  {

    int index1 = i1 + nx * j;
    int index2 = i2 + nx * j;

    fin[index1 + 6 * nxny] = fin[index2 + 6 * nxny];
    fin[index1 + 7 * nxny] = fin[index2 + 7 * nxny];
    fin[index1 + 8 * nxny] = fin[index2 + 8 * nxny];

  } // end for j

} // border_outflow

// ======================================================
void macroscopic(const LBMParams &params,
                 const double *v,
                 const double *fin,
                 double *rho,
                 double *ux,
                 double *uy)
{

  const int nx = params.nx;
  const int ny = params.ny;
  const int npop = params.npop;

#pragma acc parallel loop gang worker vector vector_length(32) present(ux, uy, fin, rho, v)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {
      int base_index = i + nx * j;

      double rho_tmp = 0;
      double ux_tmp = 0;
      double uy_tmp = 0;
      double tempFin = 0.0;

#pragma acc loop seq
      for (int ipop = 0; ipop < npop; ++ipop)
      {

        int index = base_index + ipop * nx * ny;
        tempFin = fin[index];
        // Oth order moment
        rho_tmp += tempFin;

        // 1st order moment
        ux_tmp += v[ipop * 2] * tempFin;
        uy_tmp += v[ipop * 2 + 1] * tempFin;

      } // end for ipop

      rho[base_index] = rho_tmp;
      ux[base_index] = ux_tmp / rho_tmp;
      uy[base_index] = uy_tmp / rho_tmp;

    } // end for i
  }   // end for j

} // macroscopic

// ======================================================
void border_inflow(const LBMParams &params,
                   const double *fin,
                   double *rho,
                   double *ux,
                   double *uy)
{

  const int nx = params.nx;
  const int ny = params.ny;

  const double uLB = params.uLB;
  const double ly = params.ly;

  const int nxny = nx * ny;

  const int i = 0;
#pragma acc parallel loop gang worker vector vector_length(128) present(ux, uy, rho, fin)
  for (int j = 0; j < ny; ++j)
  {

    int index = i + nx * j;

    ux[index] = compute_vel(0, i, j, uLB, ly);
    uy[index] = compute_vel(1, i, j, uLB, ly);
    rho[index] = 1 / (1 - ux[index]) *
                 (fin[index + 3 * nxny] + fin[index + 4 * nxny] + fin[index + 5 * nxny] +
                  2 * (fin[index + 6 * nxny] + fin[index + 7 * nxny] + fin[index + 8 * nxny]));

  } // end for j

} // border_inflow

void equilibrium(const LBMParams &params,
                 const double *v,
                 const double *t,
                 const double *rho,
                 const double *ux,
                 const double *uy,
                 double *feq)
{

  const int nx = params.nx;
  const int ny = params.ny;
  const int npop = params.npop;

#pragma acc parallel loop gang vector vector_length(32) present(ux, uy, feq, rho, t, v)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop worker vector
    for (int i = 0; i < nx; ++i)
    {

      int index = i + nx * j;

      double usqr = 3.0 / 2 * (ux[index] * ux[index] + uy[index] * uy[index]);
#pragma acc loop seq
      for (int ipop = 0; ipop < npop; ++ipop)
      {
        double cu = 3 * (v[ipop * 2] * ux[index] +
                         v[ipop * 2 + 1] * uy[index]);

        feq[index + ipop * nx * ny] = rho[index] * t[ipop] * (1 + cu + 0.5 * cu * cu - usqr);
      }

    } // end for i
  }   // end for j

} // equilibrium

void update_fin_inflow(const LBMParams &params,
                       const double *feq,
                       double *fin)
{

  const int nx = params.nx;
  const int ny = params.ny;

  const int nxny = nx * ny;

  int i = 0;

#pragma acc parallel loop gang worker vector vector_length(128) present(feq, fin)
  for (int j = 0; j < ny; ++j)
  {
    int index = i + nx * j;

    fin[index + 0 * nxny] = feq[index + 0 * nxny] + fin[index + 8 * nxny] - feq[index + 8 * nxny];
    fin[index + 1 * nxny] = feq[index + 1 * nxny] + fin[index + 7 * nxny] - feq[index + 7 * nxny];
    fin[index + 2 * nxny] = feq[index + 2 * nxny] + fin[index + 6 * nxny] - feq[index + 6 * nxny];

  } // end for j

} // update_fin_inflow

// ======================================================
void compute_collision(const LBMParams &params,
                       const double *fin,
                       const double *feq,
                       double *fout)
{

  const int nx = params.nx;
  const int ny = params.ny;

  const int nxny = nx * ny;

  const int npop = params.npop;
  const double omega = params.omega;

#pragma acc parallel loop gang worker vector vector_length(64) present(fin, feq, fout)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {
      int index = i + nx * j;
#pragma acc loop seq
      for (int ipop = 0; ipop < npop; ++ipop)
      {
        int index_f = index + ipop * nxny;

        fout[index_f] = fin[index_f] - omega * (fin[index_f] - feq[index_f]);
      } // end for ipop

    } // end for i
  }   // end for j

} // compute_collision

// ======================================================
void update_obstacle(const LBMParams &params,
                     const double *fin,
                     const uint8_t *obstacle,
                     double *fout)
{

  const int nx = params.nx;
  const int ny = params.ny;
  const int nxny = nx * ny;
  const int npop = params.npop;

#pragma acc parallel loop gang worker vector vector_length(64) present(fin, fout, obstacle)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {

      int index = i + nx * j;

      if (obstacle[index] == 1)
      {
#pragma acc loop seq
        for (int ipop = 0; ipop < npop; ++ipop)
        {

          int index_out = index + ipop * nxny;
          int index_in = index + (8 - ipop) * nxny;

          fout[index_out] = fin[index_in];

        } // end for ipop

      } // end inside obstacle

    } // end for i
  }   // end for j

} // update_obstacle

// ======================================================
// ======================================================
void streaming(const LBMParams &params,
               const double *v,
               const double *fout,
               double *fin)
{

  const int nx = params.nx;
  const int ny = params.ny;
  const int nxny = nx * ny;
  const int npop = params.npop;

#pragma acc parallel loop gang worker vector vector_length(128) present(fin, fout, v)
  for (int j = 0; j < ny; ++j)
  {
#pragma acc loop vector
    for (int i = 0; i < nx; ++i)
    {
      int index = i + nx * j;
#pragma acc loop seq
      for (int ipop = 0; ipop < npop; ++ipop)
      {
        int index_in = index + ipop * nxny;
        int i_out = i - v[2 * ipop];
        if (i_out < 0)
          i_out += nx;
        if (i_out > nx - 1)
          i_out -= nx;

        int j_out = j - v[2 * ipop + 1];
        if (j_out < 0)
          j_out += ny;
        if (j_out > ny - 1)
          j_out -= ny;

        int index_out = i_out + nx * j_out + ipop * nxny;

        fin[index_in] = fout[index_out];

      } // end for ipop

    } // end for i

  } // end for j

} // streaming
