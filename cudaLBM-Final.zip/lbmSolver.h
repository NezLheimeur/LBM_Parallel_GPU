#ifndef LBM_SOLVER_H
#define LBM_SOLVER_H

#include "lbmParams.h"
#include "lbmUtilities.h"

/**
 * class LBMSolver for D2Q9
 *
 * Adapted and translated to C++ from original python version
 * found here :
 * https://github.com/sidsriv/Simulation-and-modelling-of-natural-processes
 *
 * LBM lattice : D2Q9
 *
 * 6   3   0
 *  \  |  /
 *   \ | /
 * 7---4---1
 *   / | \
 *  /  |  \
 * 8   5   2
 *
 */
class LBMSolver
{
public:
    int nx;
    int ny;
    int npop;
    
    // distribution functions
    double *fin{nullptr};
    double *fout{nullptr};
    double *feq{nullptr};

    // macroscopic variables
    double *rho{nullptr};
    double *ux{nullptr};
    double *uy{nullptr};

    // obstacle
    uint8_t *obstacle{nullptr};

public:
    LBMSolver(const LBMParams &params);
    ~LBMSolver();

    //! LBM weight for D2Q9
    const double t[9] = {1.0 / 36, 1.0 / 9, 1.0 / 36, 1.0 / 9, 4.0 / 9, 1.0 / 9, 1.0 / 36, 1.0 / 9, 1.0 / 36};

    // LBM lattive velocity (X and Y components) for D2Q9
    const double v[9 * 2]{
        1, 1,
        1, 0,
        1, -1,
        0, 1,
        0, 0,
        0, -1,
        -1, 1,
        -1, 0,
        -1, -1};

    const LBMParams &params;

    void initialize();

    void output_png(int iTime);

    void run();
    // void output_png(int iTime);
    // void output_vtk(int iTime);

}; // class LBMSolver

#endif // LBM_SOLVER_H
