#include <iostream>
#include "lbmSolver.h"
#include "lbmUtilities.h"
#include "lbmParams.h"
#include <chrono>

int main(int argc, char **argv)
{

    typedef std::chrono::high_resolution_clock Time;

    // test: create a LBMParams object
    LBMParams params = LBMParams(); //420, 180
    params.setup(20000, 420, 180, 0.04, 150.0);
    params.print();

    // Instanciate solver class
    LBMSolver mySolver = LBMSolver(params);

    auto start = Time::now();
    mySolver.initialize();
    mySolver.run();
    auto end = Time::now();

    double diff = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    std::cout << "Elapsed time : " << diff << std::endl;


    return (0);
}
