#include <cstdlib> // for malloc
#include <iostream>
#include <vector>
#include <sstream>

#include "lbmSolver.h"
#include "lbmUtilities.h"
#include "writePNG/lodepng.h"
#include "real_type.h"

// ======================================================
// ======================================================
LBMSolver::LBMSolver(const LBMParams &params) : params(params)
{

    this->nx = params.nx;
    this->ny = params.ny;
    this->npop = params.npop;

    // memory allocations

    // distribution functions
    this->fin = (double *)malloc(nx * ny * npop * sizeof(double));
    this->fout = (double *)malloc(nx * ny * npop * sizeof(double));
    this->feq = (double *)malloc(nx * ny * npop * sizeof(double));

    // macroscopic variables
    this->rho = (double *)malloc(nx * ny * sizeof(double));
    this->ux = (double *)malloc(nx * ny * sizeof(double));
    this->uy = (double *)malloc(nx * ny * sizeof(double));

    // obstacle
    this->obstacle = (uint8_t *)malloc(nx * ny * sizeof(uint8_t));

#pragma acc enter data copyin(this)
#pragma acc enter data create(fin[:(nx * ny * npop)], feq[:(nx * ny * npop)], fout[:(nx * ny * npop)], obstacle[:nx * ny], rho[:nx * ny], ux[:nx * ny], uy[:nx * ny]) copyin(t[:npop], v[:(npop * 2)])
} // LBMSolver::LBMSolver

// ======================================================
// ======================================================
LBMSolver::~LBMSolver()
{
    // free memory

    // distribution functions
    delete[] fin;
    delete[] fout;
    delete[] feq;

    // macroscopic variables
    delete[] rho;
    delete[] ux;
    delete[] uy;

    // obstacle
    delete[] obstacle;

#pragma acc exit data delete (fin[:(nx * ny * npop)], feq[:(nx * ny * npop)], fout[:(nx * ny * npop)], obstacle[:nx * ny], rho[:nx * ny], ux[:nx * ny], uy[:nx * ny], t[:npop], v[:(npop * 2)])
#pragma acc exit data delete (this)
    std::cout << "Destruction done" << std::endl;

} // LBMSolver::~LBMSolver

// ======================================================
// ======================================================
void LBMSolver::initialize()
{

    // initialize obstacle mask array
    init_obstacle_mask(params,
                       obstacle);

    // initialize macroscopic velocity
    initialize_macroscopic_variables(params,
                                     rho,
                                     ux,
                                     uy);

#pragma acc wait(2)
    // Initialization of the populations at equilibrium
    // with the given macroscopic variables.
    initialize_equilibrium(params, v, t, rho, ux, uy, fin);
#pragma acc update self(uy[:nx * ny]) async(3)
    // std::cout << "Init equi done" << std::endl;

#pragma acc wait(3)
#pragma acc wait(4)
}
void LBMSolver::run()
{

    int maxIter = params.maxIter;

    //------------------------LOOP------------------------
    for (size_t iter = 0; iter <= maxIter; iter++)
    {
        if (!(iter % 100))
        {
#pragma acc update self(uy[:nx * ny], ux[:nx * ny])
            output_png(iter);
        }

        border_outflow(params, fin);

        macroscopic(params,
                    v,
                    fin,
                    rho,
                    ux,
                    uy);
        //     std::cout << "macro done" << std::endl;

        border_inflow(params,
                      fin,
                      rho,
                      ux,
                      uy);

        equilibrium(params,
                    v,
                    t,
                    rho,
                    ux,
                    uy,
                    feq);

        update_fin_inflow(params,
                          feq,
                          fin);

        compute_collision(params,
                          fin,
                          feq,
                          fout);

        update_obstacle(params,
                        fin,
                        obstacle,
                        fout);

        streaming(params,
                  v,
                  fout,
                  fin);
    }
} // LBMSolver::initialize

void LBMSolver::output_png(int iTime)
{

    std::cout << "Output data (PNG) at time " << iTime << "\n";

    const int nx = params.nx;
    const int ny = params.ny;

    double *u2 = (double *)malloc(nx * ny * sizeof(double));

    // compute velocity norm, as well as min and max values
    double min_value = sqrt(ux[0] * ux[0] + uy[0] * uy[0]);
    double max_value = min_value;
    for (int j = 0; j < ny; ++j)
    {
        for (int i = 0; i < nx; ++i)
        {
            int index = i + nx * j;

            u2[index] = sqrt(ux[index] * ux[index] + uy[index] * uy[index]);

            if (u2[index] < min_value)
                min_value = u2[index];

            if (u2[index] > max_value)
                max_value = u2[index];

        } // end for i

    } // end for j

    // create png image buff
    std::vector<unsigned char> image;
    image.resize(nx * ny * 4);
    for (int j = 0; j < ny; ++j)
    {
        for (int i = 0; i < nx; ++i)
        {

            int index = i + nx * j;

            // rescale velocity in 0-255 range
            unsigned char value = static_cast<unsigned char>((u2[index] - min_value) / (max_value - min_value) * 255);
            image[0 + 4 * i + 4 * nx * j] = value;
            image[1 + 4 * i + 4 * nx * j] = value;
            image[2 + 4 * i + 4 * nx * j] = value;
            image[3 + 4 * i + 4 * nx * j] = value;
        }
    }

    std::ostringstream iTimeNum;
    iTimeNum.width(7);
    iTimeNum.fill('0');
    iTimeNum << iTime;

    std::string filename = "vel_" + iTimeNum.str() + ".png";

    // encode the image
    unsigned error = lodepng::encode(filename, image, nx, ny);

    //if there's an error, display it
    if (error)
        std::cout << "encoder error " << error << ": " << lodepng_error_text(error) << std::endl;

    delete[] u2;

} // LBMSolver::output_png
