#ifndef LBMUTILS_H
#define LBMUTILS_H
#include "stdint.h"

#pragma acc routine seq
double compute_vel(int dir,
                   int i,
                   int j,
                   double uLB,
                   double ly);

void init_obstacle_mask(const LBMParams &params, uint8_t *obstacle);

void initialize_macroscopic_variables(const LBMParams &params,
                                      double *rho,
                                      double *ux,
                                      double *uy);

void initialize_equilibrium(const LBMParams &params,
                            const double *v,
                            const double *t,
                            const double *rho,
                            const double *ux,
                            const double *uy,
                            double *fin);

//----------------------- Loop Routines -----------------------

void border_outflow(const LBMParams &params,
                    double *fin);

void macroscopic(const LBMParams &params,
                 const double *v,
                 const double *fin,
                 double *rho,
                 double *ux,
                 double *uy);

void border_inflow(const LBMParams &params,
                   const double *fin,
                   double *rho,
                   double *ux,
                   double *uy);

void equilibrium(const LBMParams &params,
                 const double *v,
                 const double *t,
                 const double *rho,
                 const double *ux,
                 const double *uy,
                 double *feq);

void update_fin_inflow(const LBMParams &params,
                       const double *feq,
                       double *fin);

void compute_collision(const LBMParams &params,
                       const double *fin,
                       const double *feq,
                       double *fout);

void update_obstacle(const LBMParams &params,
                     const double *fin,
                     const uint8_t *obstacle,
                     double *fout);

void streaming(const LBMParams &params,
               const double *v,
               const double *fout,
               double *fin);

#endif
