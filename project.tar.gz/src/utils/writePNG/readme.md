PNG image writer routine comes from 
https://github.com/lvandeve/lodepng
commit 4d4a406

Nov 12th, 2019.
